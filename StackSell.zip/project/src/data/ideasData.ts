// Mock data for business ideas
export const ideasData = [
  {
    id: "instagram-reels-automation",
    title: "Instagram Reels Automation",
    description: "Create and sell automated Instagram Reels services to local businesses using simple no-code tools.",
    image: "https://images.pexels.com/photos/6177562/pexels-photo-6177562.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["Social Media", "Automation", "Teen Friendly"],
    earnings: "₹15,000-₹40,000/mo",
    difficulty: "Easy",
    investmentRequired: "None",
    steps: [
      "Set up an Instagram Business account",
      "Learn Reels creation basics with our tutorial",
      "Use our templates to create engaging Reels",
      "Start with local businesses in your area",
      "Scale by hiring freelancers as you grow"
    ],
    toolsRequired: [
      "Smartphone with good camera",
      "CapCut or InShot (free apps)",
      "StackSell Reels templates (included)"
    ],
    potentialEarnings: "₹1,500-₹5,000 per client per month, with 10+ clients possible",
    fullDescription: "Help local businesses grow their Instagram presence by creating engaging Reels content. This business requires zero investment, just your smartphone and our included templates. Perfect for teenagers and students who are comfortable with social media."
  },
  {
    id: "affiliate-kit-reselling",
    title: "Affiliate Kit Reselling",
    description: "Earn by reselling ready-made affiliate marketing kits to people wanting to start online businesses.",
    image: "https://images.pexels.com/photos/6693661/pexels-photo-6693661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["Affiliate Marketing", "Digital Products", "Beginner Friendly"],
    earnings: "₹50,000-₹1,00,000/mo",
    difficulty: "Medium",
    investmentRequired: "Low",
    steps: [
      "Get our exclusive affiliate kit bundle",
      "Set up your landing page (template provided)",
      "Run basic ads on Instagram/Facebook",
      "Collect leads and do sales calls",
      "Deliver the kits and collect payment"
    ],
    toolsRequired: [
      "Computer/Laptop",
      "StackSell Affiliate Kit Bundle",
      "Basic internet marketing knowledge"
    ],
    potentialEarnings: "₹2,000-₹5,000 profit per kit sold, with potential to sell 10-20 kits per month",
    fullDescription: "This business model lets you resell our premium affiliate marketing kits that include landing pages, ad creatives, and step-by-step guides. You'll earn the difference between our wholesale price and your selling price, with huge margins possible."
  },
  {
    id: "lead-generation-local",
    title: "Lead Generation for Local Businesses",
    description: "Generate qualified leads for local businesses like dentists, plumbers, and restaurants and get paid per lead.",
    image: "https://images.pexels.com/photos/8867482/pexels-photo-8867482.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["Local Business", "Marketing", "Skill-Based"],
    earnings: "₹30,000-₹80,000/mo",
    difficulty: "Medium",
    investmentRequired: "Low",
    steps: [
      "Choose a local business niche (dentists, plumbers, etc.)",
      "Use our templates to create a lead gen landing page",
      "Set up targeted Facebook/Google ads (guide included)",
      "Deliver leads to businesses and charge per qualified lead",
      "Expand to multiple businesses in same niche"
    ],
    toolsRequired: [
      "Computer/Laptop",
      "StackSell Lead Gen templates",
      "Small ad budget (₹5,000 to start)"
    ],
    potentialEarnings: "₹200-₹1,000 per qualified lead depending on industry, with potential for 100+ leads per month",
    fullDescription: "Local businesses are always looking for new customers. With this model, you'll create simple landing pages and run targeted ads to generate leads for these businesses. You get paid for each qualified lead you deliver, with some industries paying ₹1,000+ per lead."
  },
  {
    id: "print-on-demand",
    title: "Print-on-Demand T-shirt Business",
    description: "Create and sell custom t-shirts, mugs, and merchandise without inventory or upfront costs.",
    image: "https://images.pexels.com/photos/5709661/pexels-photo-5709661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["E-commerce", "Passive Income", "Creative"],
    earnings: "₹20,000-₹60,000/mo",
    difficulty: "Easy",
    investmentRequired: "None",
    steps: [
      "Sign up for Printify or Printful (free)",
      "Create designs using our templates or Canva",
      "Set up a Shopify or Etsy store",
      "Market your products on social media",
      "Orders are printed and shipped automatically"
    ],
    toolsRequired: [
      "Computer/Laptop",
      "Design tools (Canva free account)",
      "StackSell design templates"
    ],
    potentialEarnings: "₹300-₹500 profit per item sold, with potential to sell 100+ items per month once established",
    fullDescription: "Print-on-demand is perfect for creative people who want to sell physical products without inventory. You create designs, upload them to products like t-shirts and mugs, and they're printed and shipped only when a customer orders. No inventory, no risk!"
  },
  {
    id: "crypto-automation",
    title: "Crypto Trading Automation",
    description: "Offer crypto trading bot setups and management services to people interested in passive crypto income.",
    image: "https://images.pexels.com/photos/6780789/pexels-photo-6780789.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["Crypto", "Automation", "Investment"],
    earnings: "₹40,000-₹1,50,000/mo",
    difficulty: "Hard",
    investmentRequired: "Medium",
    steps: [
      "Learn our pre-configured trading bot setups",
      "Create demo accounts showing performance",
      "Market to crypto enthusiasts on Telegram/Discord",
      "Charge setup fee + monthly management fee",
      "Provide regular performance reports to clients"
    ],
    toolsRequired: [
      "Computer/Laptop",
      "StackSell Crypto Bot access",
      "Basic crypto knowledge"
    ],
    potentialEarnings: "₹5,000-₹10,000 setup fee per client + ₹2,000-₹5,000 monthly management fee",
    fullDescription: "Many people are interested in crypto trading but lack the technical knowledge. You'll provide a service setting up and managing automated trading bots for clients using our proven configurations. Charge an upfront setup fee and ongoing monthly management fee."
  },
  {
    id: "youtube-automation",
    title: "YouTube Automation Channel",
    description: "Create and monetize YouTube channels with minimal face time by using templates and outsourcing content creation.",
    image: "https://images.pexels.com/photos/4006576/pexels-photo-4006576.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["Content Creation", "Passive Income", "Outsourcing"],
    earnings: "₹25,000-₹1,50,000/mo",
    difficulty: "Medium",
    investmentRequired: "Medium",
    steps: [
      "Choose a profitable niche from our guide",
      "Use our script templates for video content",
      "Hire voice actors from Fiverr (₹500-₹1000 per video)",
      "Use simple video editing tools (templates included)",
      "Upload consistently and monetize with ads/affiliate"
    ],
    toolsRequired: [
      "Computer/Laptop",
      "StackSell YouTube templates",
      "Basic video editing software (free options available)"
    ],
    potentialEarnings: "₹25,000-₹1,50,000 per month from ads, affiliates, and sponsorships once channel grows",
    fullDescription: "YouTube automation is creating content without showing your face. You research topics, write scripts, and outsource voice recording and editing. Once set up, these channels can generate passive income through ads, affiliate marketing, and sponsorships."
  },
  {
    id: "whatsapp-marketing",
    title: "WhatsApp Marketing Agency",
    description: "Help businesses set up and manage WhatsApp Business accounts and campaigns for customer engagement.",
    image: "https://images.pexels.com/photos/5935787/pexels-photo-5935787.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["Marketing", "Local Business", "Teen Friendly"],
    earnings: "₹20,000-₹60,000/mo",
    difficulty: "Easy",
    investmentRequired: "None",
    steps: [
      "Learn WhatsApp Business features (guide included)",
      "Create a portfolio of message templates",
      "Approach local businesses with our pitch deck",
      "Set up their WhatsApp Business API",
      "Charge monthly fee for management & campaigns"
    ],
    toolsRequired: [
      "Smartphone",
      "StackSell WhatsApp templates",
      "Basic marketing knowledge"
    ],
    potentialEarnings: "₹3,000-₹8,000 per client per month, with 10+ clients possible",
    fullDescription: "WhatsApp is the most used messaging app in India, making it perfect for business marketing. You'll help businesses set up WhatsApp Business, create message templates, and manage campaigns. This requires no investment and can be started immediately."
  },
  {
    id: "dropshipping-niche",
    title: "Niche Dropshipping Store",
    description: "Build a focused dropshipping store in a specific niche with high profit margins and less competition.",
    image: "https://images.pexels.com/photos/6169/woman-hand-smartphone-desk.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["E-commerce", "Dropshipping", "Investment"],
    earnings: "₹30,000-₹2,00,000/mo",
    difficulty: "Medium",
    investmentRequired: "Medium",
    steps: [
      "Choose from our list of 50 profitable niches",
      "Set up a Shopify store (template included)",
      "Source products from our verified suppliers",
      "Use our proven ad strategies for Facebook/Instagram",
      "Scale winning products and expand inventory"
    ],
    toolsRequired: [
      "Computer/Laptop",
      "StackSell Dropshipping Kit",
      "Ad budget (₹15,000+ recommended)"
    ],
    potentialEarnings: "₹500-₹2,000 profit per sale, with 50-100+ sales per month possible when scaled",
    fullDescription: "Our approach to dropshipping focuses on specific niches with less competition and higher margins. We provide verified suppliers, winning product research, and proven ad strategies so you can avoid the typical dropshipping pitfalls."
  },
  {
    id: "graphic-design-templates",
    title: "Graphic Design Templates",
    description: "Create and sell graphic design templates on marketplaces like Canva and Etsy for passive income.",
    image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    category: ["Digital Products", "Creative", "Passive Income"],
    earnings: "₹15,000-₹50,000/mo",
    difficulty: "Medium",
    investmentRequired: "None",
    steps: [
      "Learn basic design skills with our tutorial",
      "Use Canva Pro to create templates (guide included)",
      "Sell on Canva Template Marketplace",
      "Expand to Etsy, Creative Market, etc.",
      "Create bundle offers for higher average order value"
    ],
    toolsRequired: [
      "Computer/Laptop",
      "Canva Pro (₹499/month)",
      "StackSell Design Templates Guide"
    ],
    potentialEarnings: "₹200-₹2,000 per template sold, with potential for hundreds of sales per month once portfolio grows",
    fullDescription: "Creating and selling design templates is perfect for creative people looking for passive income. Once created, these templates can sell for years with no additional work. Our guide shows you which templates sell best and how to market them effectively."
  }
];