import { useState } from 'react';
import { motion } from 'framer-motion';

interface IdeaFilterProps {
  onFilterChange: (filters: {
    category: string | null;
    difficulty: string | null;
    investment: string | null;
  }) => void;
  categories: string[];
}

const IdeaFilter = ({ onFilterChange, categories }: IdeaFilterProps) => {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeDifficulty, setActiveDifficulty] = useState<string | null>(null);
  const [activeInvestment, setActiveInvestment] = useState<string | null>(null);

  const handleCategoryChange = (category: string | null) => {
    const newCategory = activeCategory === category ? null : category;
    setActiveCategory(newCategory);
    onFilterChange({
      category: newCategory,
      difficulty: activeDifficulty,
      investment: activeInvestment
    });
  };

  const handleDifficultyChange = (difficulty: string | null) => {
    const newDifficulty = activeDifficulty === difficulty ? null : difficulty;
    setActiveDifficulty(newDifficulty);
    onFilterChange({
      category: activeCategory,
      difficulty: newDifficulty,
      investment: activeInvestment
    });
  };

  const handleInvestmentChange = (investment: string | null) => {
    const newInvestment = activeInvestment === investment ? null : investment;
    setActiveInvestment(newInvestment);
    onFilterChange({
      category: activeCategory,
      difficulty: activeDifficulty,
      investment: newInvestment
    });
  };

  const resetFilters = () => {
    setActiveCategory(null);
    setActiveDifficulty(null);
    setActiveInvestment(null);
    onFilterChange({
      category: null,
      difficulty: null,
      investment: null
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-xl shadow-md p-6 mb-8"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <h3 className="text-xl font-semibold mb-4 md:mb-0">Filter Ideas</h3>
        <button
          onClick={resetFilters}
          className="text-primary-500 hover:text-primary-600 transition-colors font-medium text-sm"
        >
          Reset Filters
        </button>
      </div>
      
      <div className="space-y-6">
        <div>
          <h4 className="text-gray-700 font-medium mb-3">Category</h4>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => handleCategoryChange(category)}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeCategory === category
                    ? 'bg-primary-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="text-gray-700 font-medium mb-3">Difficulty Level</h4>
          <div className="flex flex-wrap gap-2">
            {['Easy', 'Medium', 'Hard'].map((difficulty) => (
              <button
                key={difficulty}
                onClick={() => handleDifficultyChange(difficulty)}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeDifficulty === difficulty
                    ? 'bg-primary-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {difficulty}
              </button>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="text-gray-700 font-medium mb-3">Investment Required</h4>
          <div className="flex flex-wrap gap-2">
            {['None', 'Low', 'Medium', 'High'].map((investment) => (
              <button
                key={investment}
                onClick={() => handleInvestmentChange(investment)}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeInvestment === investment
                    ? 'bg-primary-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {investment}
              </button>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default IdeaFilter;