import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

export interface IdeaProps {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string[];
  earnings: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  investmentRequired: 'None' | 'Low' | 'Medium' | 'High';
  index?: number;
}

const IdeaCard = ({ id, title, description, image, category, earnings, difficulty, investmentRequired, index = 0 }: IdeaProps) => {
  const difficultyColor = 
    difficulty === 'Easy' ? 'text-green-600 bg-green-50' :
    difficulty === 'Medium' ? 'text-yellow-600 bg-yellow-50' :
    'text-red-600 bg-red-50';

  const investmentColor =
    investmentRequired === 'None' ? 'text-green-600 bg-green-50' :
    investmentRequired === 'Low' ? 'text-blue-600 bg-blue-50' :
    investmentRequired === 'Medium' ? 'text-yellow-600 bg-yellow-50' :
    'text-red-600 bg-red-50';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow border border-gray-100"
    >
      <div className="relative">
        <img
          src={image}
          alt={title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-0 left-0 p-2">
          <span className="inline-block px-3 py-1 text-xs font-medium text-primary-600 bg-white rounded-full shadow-sm">
            Earn: {earnings}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <div className="flex flex-wrap gap-2 mb-3">
          {category.map((tag, idx) => (
            <span 
              key={idx} 
              className="inline-block px-2 py-1 text-xs font-medium text-gray-600 bg-gray-100 rounded-md"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-2">{description}</p>
        
        <div className="flex items-center justify-between mb-4">
          <span className={`inline-block px-2 py-1 text-xs font-medium rounded-md ${difficultyColor}`}>
            {difficulty}
          </span>
          <span className={`inline-block px-2 py-1 text-xs font-medium rounded-md ${investmentColor}`}>
            Investment: {investmentRequired}
          </span>
        </div>
        
        <Link
          to={`/explore/${id}`}
          className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700 transition-colors"
        >
          View Details
          <ArrowRight className="ml-1 h-4 w-4" />
        </Link>
      </div>
    </motion.div>
  );
};

export default IdeaCard;