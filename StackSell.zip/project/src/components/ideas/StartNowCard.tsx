import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const StartNowCard = () => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-primary-500 text-white rounded-xl shadow-lg p-8 sticky top-24"
    >
      <h3 className="text-2xl font-bold mb-3">Ready to Start?</h3>
      <p className="opacity-90 mb-6">
        Get all the tools, templates, and guidance you need to start this business today.
      </p>
      
      <ul className="space-y-3 mb-6">
        <li className="flex items-start">
          <svg className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span>Step-by-step guides included</span>
        </li>
        <li className="flex items-start">
          <svg className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span>Ready-to-use templates</span>
        </li>
        <li className="flex items-start">
          <svg className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span>Access to community for help</span>
        </li>
        <li className="flex items-start">
          <svg className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span>Expert support when needed</span>
        </li>
      </ul>
      
      <Link
        to="/signup"
        className="btn bg-white text-primary-600 hover:bg-gray-100 focus:ring-white w-full flex justify-center items-center"
      >
        Start This Now
        <ArrowRight className="ml-2 h-5 w-5" />
      </Link>
      
      <div className="mt-6 pt-6 border-t border-primary-400">
        <div className="flex items-center justify-between mb-2">
          <span className="font-medium">Free Starter Kit</span>
          <Link to="#" className="text-white/80 hover:text-white underline text-sm">
            Download
          </Link>
        </div>
        <div className="flex items-center justify-between">
          <span className="font-medium">View Pricing</span>
          <Link to="/pricing" className="text-white/80 hover:text-white underline text-sm">
            See Plans
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default StartNowCard;