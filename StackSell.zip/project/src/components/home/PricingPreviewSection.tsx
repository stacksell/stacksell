import { Link } from 'react-router-dom';
import { Check, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const plans = [
  {
    name: "Free",
    price: "₹0",
    description: "Get started with basic ideas and tools",
    features: [
      "5 Basic Business Ideas",
      "Starter Templates",
      "Community Access",
      "Email Support"
    ],
    cta: "Start Free",
    link: "/signup",
    popular: false
  },
  {
    name: "Starter",
    price: "₹499",
    description: "Everything you need to start earning",
    features: [
      "20+ Profitable Business Ideas",
      "Complete Starter Kits",
      "Step-by-Step Tutorials",
      "1-on-1 Setup Assistance",
      "Priority Support"
    ],
    cta: "Get Started",
    link: "/pricing",
    popular: true
  },
  {
    name: "Premium",
    price: "₹1,999",
    description: "Advanced tools for serious earners",
    features: [
      "All Starter Features",
      "50+ Premium Business Ideas",
      "Ready-to-Use Scripts & Bots",
      "Unlimited Resellable Products",
      "Weekly Coaching Calls",
      "VIP Support"
    ],
    cta: "Upgrade Now",
    link: "/pricing",
    popular: false
  }
];

const PricingPreviewSection = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-primary-500 font-medium mb-2 block"
          >
            PRICING
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Simple, Transparent Pricing
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            Choose the plan that's right for your journey. Start free and upgrade as you grow.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative rounded-xl overflow-hidden ${
                plan.popular 
                  ? 'border-2 border-primary-500 shadow-lg' 
                  : 'border border-gray-200 shadow-md'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0 bg-primary-500 text-white px-4 py-1 text-sm font-medium">
                  Most Popular
                </div>
              )}
              <div className="p-8">
                <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-500 ml-2">/lifetime</span>
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <Check className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Link 
                  to={plan.link}
                  className={`block text-center py-3 px-6 rounded-lg font-medium transition-colors w-full ${
                    plan.popular
                      ? 'bg-primary-500 text-white hover:bg-primary-600'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link 
            to="/pricing" 
            className="inline-flex items-center text-primary-500 font-medium hover:text-primary-600 transition-colors"
          >
            View Full Pricing Details
            <ChevronRight className="ml-1 h-5 w-5" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PricingPreviewSection;