import { Link } from 'react-router-dom';
import { Download, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const StarterKitSection = () => {
  return (
    <section className="py-24 bg-primary-500 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/7821644/pexels-photo-7821644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] opacity-10 bg-cover bg-center" />
      
      <div className="container-custom relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <span className="inline-block px-4 py-2 rounded-full bg-white text-primary-600 font-medium text-sm mb-6">
              FREE DOWNLOAD
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Get Our "Success Starter Kit" For Free
            </h2>
            <p className="text-lg opacity-90 mb-8 max-w-xl">
              Everything you need to start your online money-making journey today. Step-by-step guides, templates, and resources to kickstart your success.
            </p>
            
            <ul className="space-y-3 mb-8">
              <li className="flex items-center">
                <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span>10 Beginner-Friendly Business Ideas</span>
              </li>
              <li className="flex items-center">
                <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span>Complete Instagram Business Setup Guide</span>
              </li>
              <li className="flex items-center">
                <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span>Ready-to-Use Marketing Templates</span>
              </li>
              <li className="flex items-center">
                <svg className="h-5 w-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span>Exclusive Discount Codes for Tools</span>
              </li>
            </ul>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                className="btn bg-white text-primary-600 hover:bg-gray-100 focus:ring-white"
              >
                <Download className="mr-2 h-5 w-5" />
                Download Free Kit
              </button>
              <Link 
                to="/explore" 
                className="btn bg-primary-600 text-white hover:bg-primary-700 border border-primary-400 focus:ring-white"
              >
                Explore All Ideas
                <ChevronRight className="ml-1 h-5 w-5" />
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="hidden lg:block relative"
          >
            <div className="bg-white rounded-2xl shadow-2xl p-6 transform rotate-3">
              <img 
                src="https://images.pexels.com/photos/6177607/pexels-photo-6177607.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Success Starter Kit Preview" 
                className="rounded-lg w-full"
              />
              <div className="mt-4">
                <h3 className="text-xl font-semibold text-gray-900">Success Starter Kit</h3>
                <p className="text-gray-600">Everything you need to start earning online</p>
              </div>
            </div>
            
            <div className="absolute top-10 -right-8 bg-white rounded-lg shadow-xl p-4 transform -rotate-6">
              <div className="flex items-center">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <svg className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Downloaded 10,000+ times</p>
                  <p className="text-sm text-gray-500">Join the success community</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default StarterKitSection;