import { Zap, Coins, Users } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    icon: <Zap className="h-8 w-8 text-primary-500" />,
    title: "Easy Start",
    description: "Get up and running in minutes with our step-by-step guides and ready-to-use templates for any type of online business."
  },
  {
    icon: <Coins className="h-8 w-8 text-primary-500" />,
    title: "No Coding Required",
    description: "All our business kits and tools are designed for beginners with zero technical knowledge. Just follow the steps."
  },
  {
    icon: <Users className="h-8 w-8 text-primary-500" />,
    title: "Earn from Day 1",
    description: "Our proven ideas are designed to help you start generating income right away, not months or years down the road."
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Start Your Online Hustle <span className="text-primary-500">Without Hassle</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            We've simplified the process of starting an online business so you can focus on what matters: making money.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-xl border border-gray-100 p-8 shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="bg-primary-50 p-3 rounded-full inline-block mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;