import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const CtaSection = () => {
  return (
    <section className="py-20 bg-gradient-to-r from-primary-600 to-primary-800 text-white">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl md:text-4xl font-bold mb-6"
          >
            Ready to Start Your Online Money-Making Journey?
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xl opacity-90 mb-8"
          >
            Join thousands of students, teenagers, and entrepreneurs who are building successful online businesses with StackSell.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col sm:flex-row justify-center gap-4"
          >
            <Link 
              to="/signup" 
              className="btn bg-white text-primary-600 hover:bg-gray-100 focus:ring-white"
            >
              Start Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link 
              to="/explore" 
              className="btn bg-primary-700 text-white hover:bg-primary-800 border border-primary-500 focus:ring-white"
            >
              Explore Ideas
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;