import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { motion } from 'framer-motion';

const faqs = [
  {
    question: "What exactly is StackSell?",
    answer: "StackSell is a platform designed to help teenagers, students, and anyone looking to make money online. We provide proven business ideas, step-by-step guides, and ready-to-use tools that make it easy to start earning online without prior experience or technical skills."
  },
  {
    question: "Do I need any special skills or experience?",
    answer: "No, our business ideas and kits are designed specifically for beginners. We provide detailed guides and tutorials that walk you through every step of the process. You don't need coding skills, business experience, or specialized knowledge to get started."
  },
  {
    question: "How quickly can I start making money?",
    answer: "Many of our users start seeing their first earnings within days or weeks of implementing our ideas. The exact timeline depends on the specific business idea you choose and how much time you dedicate to it. Our Quick-Start kits are specifically designed to help you start earning as quickly as possible."
  },
  {
    question: "Is the Starter Kit really free?",
    answer: "Yes! Our Success Starter Kit is completely free. It includes basic templates, 5 beginner-friendly business ideas, and community access. We offer it for free so you can get a taste of what StackSell offers before deciding to upgrade to our paid plans."
  },
  {
    question: "What's included in the paid plans?",
    answer: "Our paid plans include access to our complete library of 50+ proven business ideas, ready-to-use scripts and tools, step-by-step tutorials, priority support, and more. The Premium plan also includes weekly coaching calls, VIP support, and unlimited access to our resellable products library."
  },
  {
    question: "Is there a refund policy?",
    answer: "Yes, we offer a 30-day money-back guarantee on all our paid plans. If you're not satisfied with your purchase for any reason, simply contact our support team within 30 days, and we'll process your refund with no questions asked."
  }
];

const FaqSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-primary-500 font-medium mb-2 block"
          >
            FREQUENTLY ASKED QUESTIONS
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Got Questions? We've Got Answers
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            Find answers to common questions about StackSell and starting your online business.
          </motion.p>
        </div>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`mb-4 border rounded-lg overflow-hidden ${
                openIndex === index ? 'border-primary-200 bg-white shadow-md' : 'border-gray-200 bg-white'
              }`}
            >
              <button
                className="w-full px-6 py-4 text-left flex justify-between items-center focus:outline-none"
                onClick={() => toggleFaq(index)}
              >
                <span className="text-lg font-medium">{faq.question}</span>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-primary-500" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400" />
                )}
              </button>
              
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <p className="text-gray-600">{faq.answer}</p>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">Still have questions?</p>
          <a 
            href="/contact" 
            className="btn-primary"
          >
            Contact Support
          </a>
        </div>
      </div>
    </section>
  );
};

export default FaqSection;