import { useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, LayoutGrid } from 'lucide-react';
import { motion } from 'framer-motion';

interface NavbarProps {
  isScrolled: boolean;
}

const Navbar = ({ isScrolled }: NavbarProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container-custom">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <LayoutGrid className="h-8 w-8 text-primary-500" />
            <span className="ml-2 text-xl font-bold text-gray-900">StackSell</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
              }
            >
              Home
            </NavLink>
            <NavLink 
              to="/pricing" 
              className={({ isActive }) => 
                isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
              }
            >
              Pricing
            </NavLink>
            <NavLink 
              to="/explore" 
              className={({ isActive }) => 
                isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
              }
            >
              Explore Ideas
            </NavLink>
            <NavLink 
              to="/affiliate" 
              className={({ isActive }) => 
                isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
              }
            >
              Affiliate
            </NavLink>
            <NavLink 
              to="/about" 
              className={({ isActive }) => 
                isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
              }
            >
              About
            </NavLink>
            <NavLink 
              to="/contact" 
              className={({ isActive }) => 
                isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
              }
            >
              Contact
            </NavLink>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Link to="/login" className="text-gray-700 hover:text-primary-500 font-medium">
              Login
            </Link>
            <Link to="/signup" className="btn-primary">
              Start Now
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700 focus:outline-none"
            onClick={toggleMenu}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="md:hidden bg-white border-t"
        >
          <div className="container-custom py-4">
            <nav className="flex flex-col space-y-4">
              <NavLink 
                to="/" 
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => 
                  isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
                }
              >
                Home
              </NavLink>
              <NavLink 
                to="/pricing" 
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => 
                  isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
                }
              >
                Pricing
              </NavLink>
              <NavLink 
                to="/explore" 
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => 
                  isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
                }
              >
                Explore Ideas
              </NavLink>
              <NavLink 
                to="/affiliate" 
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => 
                  isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
                }
              >
                Affiliate
              </NavLink>
              <NavLink 
                to="/about" 
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => 
                  isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
                }
              >
                About
              </NavLink>
              <NavLink 
                to="/contact" 
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => 
                  isActive ? 'text-primary-500 font-medium' : 'text-gray-700 hover:text-primary-500 transition-colors'
                }
              >
                Contact
              </NavLink>
              <div className="pt-2 flex flex-col space-y-2">
                <Link 
                  to="/login" 
                  onClick={() => setIsOpen(false)}
                  className="btn-secondary w-full text-center"
                >
                  Login
                </Link>
                <Link 
                  to="/signup" 
                  onClick={() => setIsOpen(false)}
                  className="btn-primary w-full text-center"
                >
                  Start Now
                </Link>
              </div>
            </nav>
          </div>
        </motion.div>
      )}
    </header>
  );
};

export default Navbar;