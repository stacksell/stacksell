import { Link } from 'react-router-dom';
import { Mail, Facebook, Twitter, Instagram, LayoutGrid } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <Link to="/" className="flex items-center mb-4">
              <LayoutGrid className="h-7 w-7 text-primary-500" />
              <span className="ml-2 text-xl font-bold text-white">StackSell</span>
            </Link>
            <p className="text-gray-400 mb-4">
              Start your online hustle with proven money-making ideas for teens, students, and anyone looking to earn online.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="mailto:contact@stacksell.com" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-medium mb-4">Quick Links</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="text-gray-400 hover:text-primary-500 transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/pricing" className="text-gray-400 hover:text-primary-500 transition-colors">Pricing</Link>
              </li>
              <li>
                <Link to="/explore" className="text-gray-400 hover:text-primary-500 transition-colors">Explore Ideas</Link>
              </li>
              <li>
                <Link to="/affiliate" className="text-gray-400 hover:text-primary-500 transition-colors">Affiliate Program</Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-primary-500 transition-colors">About Us</Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-medium mb-4">Resources</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/explore" className="text-gray-400 hover:text-primary-500 transition-colors">Making Money Online</Link>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">Success Stories</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">Blog & Guides</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">FAQ</a>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-primary-500 transition-colors">Support</Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-medium mb-4">Subscribe</h4>
            <p className="text-gray-400 mb-4">Get the latest money-making tips and exclusive offers.</p>
            <form className="mb-4">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="px-4 py-2 rounded-l-lg focus:outline-none text-gray-900 w-full"
                />
                <button
                  type="submit"
                  className="bg-primary-500 text-white px-4 py-2 rounded-r-lg hover:bg-primary-600 transition-colors"
                >
                  Subscribe
                </button>
              </div>
            </form>
            <p className="text-gray-500 text-sm">
              By subscribing you agree to our Privacy Policy
            </p>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm">
              © {currentYear} StackSell. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="#" className="text-gray-500 text-sm hover:text-gray-400 transition-colors">
                Privacy Policy
              </Link>
              <Link to="#" className="text-gray-500 text-sm hover:text-gray-400 transition-colors">
                Terms of Service
              </Link>
              <Link to="#" className="text-gray-500 text-sm hover:text-gray-400 transition-colors">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;