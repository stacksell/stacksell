import { useState } from 'react';
import { Link } from 'react-router-dom';
import { LayoutGrid, Home, Package, DollarSign, LifeBuoy, LogOut, Menu, X } from 'lucide-react';

interface DashboardSidebarProps {
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}

const DashboardSidebar = ({ mobileOpen, setMobileOpen }: DashboardSidebarProps) => {
  const [activeItem, setActiveItem] = useState('home');

  const navItems = [
    { id: 'home', label: 'Dashboard', icon: <Home className="h-5 w-5" /> },
    { id: 'kits', label: 'My Kits', icon: <Package className="h-5 w-5" /> },
    { id: 'earnings', label: 'Earnings', icon: <DollarSign className="h-5 w-5" /> },
    { id: 'support', label: 'Support', icon: <LifeBuoy className="h-5 w-5" /> }
  ];

  return (
    <>
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden fixed top-4 left-4 z-30">
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 rounded-lg bg-white shadow-md text-gray-600 focus:outline-none"
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Sidebar */}
      <div 
        className={`fixed inset-y-0 left-0 z-20 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="h-full flex flex-col">
          <div className="p-4 border-b">
            <Link 
              to="/" 
              className="flex items-center"
              onClick={() => setMobileOpen(false)}
            >
              <LayoutGrid className="h-7 w-7 text-primary-500" />
              <span className="ml-2 text-xl font-bold">StackSell</span>
            </Link>
          </div>
          
          <nav className="flex-1 pt-4 pb-4 overflow-y-auto">
            <ul className="px-2 space-y-1">
              {navItems.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      setActiveItem(item.id);
                      setMobileOpen(false);
                    }}
                    className={`flex items-center w-full px-4 py-3 rounded-lg transition-colors ${
                      activeItem === item.id
                        ? 'bg-primary-50 text-primary-600'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {item.icon}
                    <span className="ml-3 font-medium">{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
          
          <div className="p-4 border-t">
            <Link 
              to="/"
              onClick={() => setMobileOpen(false)}
              className="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <LogOut className="h-5 w-5" />
              <span className="ml-3 font-medium">Log Out</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Overlay */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-10 lg:hidden"
          onClick={() => setMobileOpen(false)}
        ></div>
      )}
    </>
  );
};

export default DashboardSidebar;