import { Check, X } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    category: "Business Ideas & Resources",
    items: [
      {
        name: "Basic Business Ideas",
        free: 5,
        starter: 20,
        premium: 50
      },
      {
        name: "Step-by-Step Guides",
        free: true,
        starter: true,
        premium: true
      },
      {
        name: "Video Tutorials",
        free: false,
        starter: true,
        premium: true
      },
      {
        name: "Resellable Products",
        free: false,
        starter: "Limited (5)",
        premium: "Unlimited"
      }
    ]
  },
  {
    category: "Tools & Templates",
    items: [
      {
        name: "Marketing Templates",
        free: "Basic",
        starter: "Advanced",
        premium: "Premium"
      },
      {
        name: "Automation Scripts",
        free: false,
        starter: "Limited (3)",
        premium: "Full Access"
      },
      {
        name: "Sales Funnels",
        free: false,
        starter: 3,
        premium: "Unlimited"
      },
      {
        name: "AI Content Tools",
        free: false,
        starter: "Limited",
        premium: "Unlimited"
      }
    ]
  },
  {
    category: "Support & Coaching",
    items: [
      {
        name: "Email Support",
        free: "72h Response",
        starter: "24h Response",
        premium: "12h Response"
      },
      {
        name: "1-on-1 Coaching",
        free: false,
        starter: "30 mins",
        premium: "Weekly"
      },
      {
        name: "Community Access",
        free: "Read Only",
        starter: "Full Access",
        premium: "VIP Access"
      },
      {
        name: "Live Q&A Sessions",
        free: false,
        starter: "Monthly",
        premium: "Weekly"
      }
    ]
  }
];

const ComparisonTable = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl md:text-4xl font-bold mb-4"
          >
            Compare All Features
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            See exactly what's included in each plan to find the right fit for your needs.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-6xl mx-auto bg-white rounded-xl shadow-md overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50">
                  <th className="py-4 px-6 border-b"></th>
                  <th className="py-4 px-6 border-b text-center">Free</th>
                  <th className="py-4 px-6 border-b text-center bg-primary-50 text-primary-700">Starter</th>
                  <th className="py-4 px-6 border-b text-center">Premium</th>
                </tr>
              </thead>
              <tbody>
                {features.map((category, categoryIndex) => (
                  <>
                    <tr key={`category-${categoryIndex}`} className="bg-gray-50">
                      <td colSpan={4} className="py-3 px-6 font-medium">
                        {category.category}
                      </td>
                    </tr>
                    {category.items.map((item, itemIndex) => (
                      <tr key={`item-${categoryIndex}-${itemIndex}`} className="border-b">
                        <td className="py-4 px-6">{item.name}</td>
                        <td className="py-4 px-6 text-center">
                          {item.free === true ? (
                            <Check className="h-5 w-5 text-green-500 mx-auto" />
                          ) : item.free === false ? (
                            <X className="h-5 w-5 text-gray-300 mx-auto" />
                          ) : (
                            <span>{item.free}</span>
                          )}
                        </td>
                        <td className="py-4 px-6 text-center bg-primary-50 text-primary-700">
                          {item.starter === true ? (
                            <Check className="h-5 w-5 text-green-500 mx-auto" />
                          ) : item.starter === false ? (
                            <X className="h-5 w-5 text-gray-300 mx-auto" />
                          ) : (
                            <span>{item.starter}</span>
                          )}
                        </td>
                        <td className="py-4 px-6 text-center">
                          {item.premium === true ? (
                            <Check className="h-5 w-5 text-green-500 mx-auto" />
                          ) : item.premium === false ? (
                            <X className="h-5 w-5 text-gray-300 mx-auto" />
                          ) : (
                            <span>{item.premium}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ComparisonTable;