import { motion } from 'framer-motion';

interface TestimonialCardProps {
  quote: string;
  name: string;
  role: string;
  image: string;
  earnings: string;
  delay?: number;
}

const TestimonialCard = ({ quote, name, role, image, earnings, delay = 0 }: TestimonialCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100"
    >
      <div className="p-6">
        <div className="flex items-center mb-4">
          <img 
            src={image} 
            alt={name} 
            className="w-12 h-12 rounded-full object-cover mr-4"
          />
          <div>
            <h4 className="font-semibold">{name}</h4>
            <p className="text-gray-500 text-sm">{role}</p>
          </div>
        </div>
        
        <p className="text-gray-700 mb-4">"{quote}"</p>
        
        <div className="bg-green-50 p-3 rounded-lg">
          <p className="text-green-700 font-medium flex items-center">
            <svg className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            Earning: {earnings}/month
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default TestimonialCard;