import { useState } from 'react';
import { Check, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

interface Plan {
  name: string;
  monthlyPrice: string;
  yearlyPrice: string;
  description: string;
  features: Array<{
    text: string;
    tooltip?: string;
  }>;
  cta: string;
  link: string;
  popular: boolean;
}

const plans: Plan[] = [
  {
    name: "Free",
    monthlyPrice: "₹0",
    yearlyPrice: "₹0",
    description: "Get started with basic ideas and tools",
    features: [
      { text: "5 Basic Business Ideas" },
      { text: "Starter Templates" },
      { text: "Community Access" },
      { text: "Email Support", tooltip: "Response within 72 hours" }
    ],
    cta: "Start Free",
    link: "/signup",
    popular: false
  },
  {
    name: "Starter",
    monthlyPrice: "₹499",
    yearlyPrice: "₹4,999",
    description: "Everything you need to start earning",
    features: [
      { text: "20+ Profitable Business Ideas" },
      { text: "Complete Starter Kits" },
      { text: "Step-by-Step Tutorials" },
      { text: "1-on-1 Setup Assistance", tooltip: "30-minute setup call with a coach" },
      { text: "Priority Support", tooltip: "Response within 24 hours" }
    ],
    cta: "Get Started",
    link: "/signup?plan=starter",
    popular: true
  },
  {
    name: "Premium",
    monthlyPrice: "₹1,999",
    yearlyPrice: "₹19,999",
    description: "Advanced tools for serious earners",
    features: [
      { text: "All Starter Features" },
      { text: "50+ Premium Business Ideas" },
      { text: "Ready-to-Use Scripts & Bots" },
      { text: "Unlimited Resellable Products", tooltip: "Full white-label rights included" },
      { text: "Weekly Coaching Calls", tooltip: "Live group calls with expert coaches" },
      { text: "VIP Support", tooltip: "Priority response within 12 hours" }
    ],
    cta: "Upgrade Now",
    link: "/signup?plan=premium",
    popular: false
  }
];

const PricingPlans = () => {
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'yearly'>('monthly');
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  const toggleBillingPeriod = () => {
    setBillingPeriod(billingPeriod === 'monthly' ? 'yearly' : 'monthly');
  };

  return (
    <section className="py-20 bg-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-primary-500 font-medium mb-2 block"
          >
            PRICING PLANS
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            Start Your Online Business Today
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            Choose the plan that fits your needs. All plans include access to our community and support.
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex justify-center mb-10"
        >
          <div className="bg-gray-100 p-1 rounded-full inline-flex items-center">
            <button
              onClick={() => setBillingPeriod('monthly')}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                billingPeriod === 'monthly'
                  ? 'bg-white text-primary-600 shadow-sm'
                  : 'text-gray-700 hover:text-primary-600'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingPeriod('yearly')}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                billingPeriod === 'yearly'
                  ? 'bg-white text-primary-600 shadow-sm'
                  : 'text-gray-700 hover:text-primary-600'
              }`}
            >
              Yearly <span className="text-green-600 ml-1">Save 20%</span>
            </button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 + (index * 0.1) }}
              className={`relative rounded-xl overflow-hidden ${
                plan.popular 
                  ? 'border-2 border-primary-500 shadow-lg' 
                  : 'border border-gray-200 shadow-md'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0 bg-primary-500 text-white px-4 py-1 text-sm font-medium">
                  Most Popular
                </div>
              )}
              <div className="p-8">
                <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold">
                    {billingPeriod === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice}
                  </span>
                  <span className="text-gray-500 ml-2">
                    {billingPeriod === 'monthly' ? '/monthly' : '/yearly'}
                  </span>
                </div>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start group relative">
                      <Check className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span>{feature.text}</span>
                      
                      {feature.tooltip && (
                        <div className="relative inline-block ml-2">
                          <HelpCircle 
                            className="h-4 w-4 text-gray-400 cursor-help"
                            onMouseEnter={() => setActiveTooltip(`${plan.name}-${featureIndex}`)}
                            onMouseLeave={() => setActiveTooltip(null)}
                          />
                          
                          {activeTooltip === `${plan.name}-${featureIndex}` && (
                            <div className="absolute z-10 w-64 px-4 py-2 text-sm text-gray-700 bg-white rounded-lg shadow-lg border border-gray-200 -top-2 left-6">
                              {feature.tooltip}
                            </div>
                          )}
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
                
                <Link 
                  to={plan.link}
                  className={`block text-center py-3 px-6 rounded-lg font-medium transition-colors w-full ${
                    plan.popular
                      ? 'bg-primary-500 text-white hover:bg-primary-600'
                      : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingPlans;