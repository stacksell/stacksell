import TestimonialCard from './TestimonialCard';

const testimonials = [
  {
    quote: "The Starter plan gave me everything I needed to start my first affiliate marketing business. Easy to follow and great support!",
    name: "Rahul Sharma",
    role: "College Student",
    image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    earnings: "₹25,000"
  },
  {
    quote: "I started with the Free plan but quickly upgraded to Premium. The scripts and automation tools alone are worth the price!",
    name: "Priya Patel",
    role: "Digital Marketer",
    image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    earnings: "₹75,000"
  },
  {
    quote: "As a teenager with no business experience, StackSell's step-by-step guides made it super easy to start my online side hustle.",
    name: "Arjun Mehta",
    role: "High School Student",
    image: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    earnings: "₹15,000"
  }
];

const TestimonialsGrid = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container-custom">
        <h3 className="text-2xl font-semibold mb-8 text-center">
          Success Stories from Our Community
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard
              key={index}
              quote={testimonial.quote}
              name={testimonial.name}
              role={testimonial.role}
              image={testimonial.image}
              earnings={testimonial.earnings}
              delay={index * 0.1}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsGrid;