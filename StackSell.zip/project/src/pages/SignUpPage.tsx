import { useEffect } from 'react';
import { motion } from 'framer-motion';
import AuthForm from '../components/auth/AuthForm';
import { LayoutGrid, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const SignUpPage = () => {
  useEffect(() => {
    // Set document title when component mounts
    document.title = 'Sign Up | StackSell';
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center py-16 px-4 bg-gray-50">
      <div className="w-full max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="hidden md:block"
          >
            <div className="text-center md:text-left">
              <Link to="/" className="inline-flex items-center mb-8">
                <LayoutGrid className="h-8 w-8 text-primary-500" />
                <span className="ml-2 text-2xl font-bold">StackSell</span>
              </Link>
              
              <h2 className="text-3xl font-bold mb-4">
                Start Your Online Business Today
              </h2>
              <p className="text-gray-600 mb-6">
                Join thousands of teens, students, and entrepreneurs who are making money online with StackSell.
              </p>
              
              <div className="bg-white p-6 rounded-xl shadow-md mb-6">
                <h3 className="font-semibold mb-4">What you'll get:</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Access to profitable business ideas</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Step-by-step guides and templates</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Community support and resources</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" />
                    <span>Free starter kit to begin immediately</span>
                  </li>
                </ul>
              </div>
              
              <div className="text-sm text-gray-600">
                Already helping 10,000+ people build online income
              </div>
            </div>
          </motion.div>
          
          <div>
            <div className="md:hidden text-center mb-8">
              <Link to="/" className="inline-flex items-center justify-center">
                <LayoutGrid className="h-8 w-8 text-primary-500" />
                <span className="ml-2 text-2xl font-bold">StackSell</span>
              </Link>
            </div>
            
            <AuthForm type="signup" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUpPage;