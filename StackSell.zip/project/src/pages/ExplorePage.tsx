import { useEffect, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import IdeaCard from '../components/ideas/IdeaCard';
import IdeaFilter from '../components/ideas/IdeaFilter';
import { ideasData } from '../data/ideasData';
import { Search } from 'lucide-react';

const ExplorePage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    category: null as string | null,
    difficulty: null as string | null,
    investment: null as string | null
  });

  // Extract all unique categories from the ideas data
  const allCategories = useMemo(() => {
    const categoriesSet = new Set<string>();
    ideasData.forEach(idea => {
      idea.category.forEach(cat => categoriesSet.add(cat));
    });
    return Array.from(categoriesSet);
  }, []);

  const filteredIdeas = useMemo(() => {
    return ideasData.filter(idea => {
      // Search query filter
      if (searchQuery) {
        const searchLower = searchQuery.toLowerCase();
        if (
          !idea.title.toLowerCase().includes(searchLower) &&
          !idea.description.toLowerCase().includes(searchLower)
        ) {
          return false;
        }
      }

      // Category filter
      if (filters.category && !idea.category.includes(filters.category)) {
        return false;
      }

      // Difficulty filter
      if (filters.difficulty && idea.difficulty !== filters.difficulty) {
        return false;
      }

      // Investment filter
      if (filters.investment && idea.investmentRequired !== filters.investment) {
        return false;
      }

      return true;
    });
  }, [searchQuery, filters]);

  const handleFilterChange = (newFilters: {
    category: string | null;
    difficulty: string | null;
    investment: string | null;
  }) => {
    setFilters(newFilters);
  };

  useEffect(() => {
    // Set document title when component mounts
    document.title = 'Explore Ideas | StackSell';
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div>
      <div className="pt-32 pb-10 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <span className="inline-block px-4 py-2 rounded-full bg-primary-100 text-primary-600 font-medium text-sm mb-4">
              START EARNING TODAY
            </span>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Explore Money-Making Ideas
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Browse our collection of proven, profitable online business ideas that you can start today.
            </p>
            
            <div className="max-w-2xl mx-auto relative">
              <input
                type="text"
                placeholder="Search for ideas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-5 py-4 pr-12 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          </motion.div>
        </div>
      </div>

      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-1">
              <IdeaFilter 
                onFilterChange={handleFilterChange}
                categories={allCategories}
              />
            </div>
            
            <div className="lg:col-span-3">
              <div className="mb-6 flex justify-between items-center">
                <h2 className="text-2xl font-semibold">
                  {filteredIdeas.length} {filteredIdeas.length === 1 ? 'Idea' : 'Ideas'} Found
                </h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredIdeas.map((idea, index) => (
                  <IdeaCard
                    key={idea.id}
                    id={idea.id}
                    title={idea.title}
                    description={idea.description}
                    image={idea.image}
                    category={idea.category}
                    earnings={idea.earnings}
                    difficulty={idea.difficulty as 'Easy' | 'Medium' | 'Hard'}
                    investmentRequired={idea.investmentRequired as 'None' | 'Low' | 'Medium' | 'High'}
                    index={index}
                  />
                ))}
              </div>
              
              {filteredIdeas.length === 0 && (
                <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                  <h3 className="text-xl font-medium mb-2">No ideas match your filters</h3>
                  <p className="text-gray-600 mb-4">Try adjusting your search or filters to find more results.</p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setFilters({
                        category: null,
                        difficulty: null,
                        investment: null
                      });
                    }}
                    className="btn-primary"
                  >
                    Reset All Filters
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ExplorePage;