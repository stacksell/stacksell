import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, PhoneCall, MessageCircle } from 'lucide-react';
import ContactForm from '../components/contact/ContactForm';
import CtaSection from '../components/home/CtaSection';

const ContactPage = () => {
  useEffect(() => {
    // Set document title when component mounts
    document.title = 'Contact Us | StackSell';
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div>
      <div className="pt-32 pb-12 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <span className="inline-block px-4 py-2 rounded-full bg-primary-100 text-primary-600 font-medium text-sm mb-4">
              GET IN TOUCH
            </span>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Contact Our Support Team
            </h1>
            <p className="text-xl text-gray-600">
              Have questions or need help? We're here for you. Reach out anytime and we'll get back to you as soon as possible.
            </p>
          </motion.div>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
              {[
                {
                  icon: <Mail className="h-8 w-8 text-primary-500" />,
                  title: "Email Us",
                  description: "Get a response within 24 hours",
                  contact: "support@stacksell.com",
                  link: "mailto:support@stacksell.com"
                },
                {
                  icon: <MessageCircle className="h-8 w-8 text-primary-500" />,
                  title: "Live Chat",
                  description: "Available 9 AM - 6 PM IST",
                  contact: "Start a chat",
                  link: "#"
                },
                {
                  icon: <PhoneCall className="h-8 w-8 text-primary-500" />,
                  title: "Call Us",
                  description: "Mon-Fri, 10 AM - 5 PM IST",
                  contact: "+91 98765 43210",
                  link: "tel:+919876543210"
                }
              ].map((method, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white rounded-xl border border-gray-200 p-6 text-center"
                >
                  <div className="bg-primary-50 p-3 inline-flex rounded-full mb-4">
                    {method.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{method.title}</h3>
                  <p className="text-gray-600 mb-4">{method.description}</p>
                  <a 
                    href={method.link} 
                    className="text-primary-600 font-medium hover:text-primary-700"
                  >
                    {method.contact}
                  </a>
                </motion.div>
              ))}
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-2xl font-bold mb-4">Send Us a Message</h2>
                <p className="text-gray-600 mb-6">
                  Whether you have a question about our plans, need technical assistance, or just want to say hello, we'd love to hear from you.
                </p>
                
                <div className="bg-gray-50 rounded-xl p-6 mb-6">
                  <h3 className="font-semibold mb-2">Before you contact us</h3>
                  <p className="text-gray-600 mb-4">
                    Check if your question has already been answered in our FAQ section.
                  </p>
                  <a 
                    href="#" 
                    className="text-primary-600 font-medium hover:text-primary-700"
                  >
                    View Frequently Asked Questions
                  </a>
                </div>
                
                <div className="bg-primary-50 rounded-xl p-6">
                  <h3 className="font-semibold mb-2">Join our Telegram community</h3>
                  <p className="text-gray-600 mb-4">
                    Get quick answers and connect with other StackSell members.
                  </p>
                  <a 
                    href="#" 
                    className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700"
                  >
                    <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2zm2.572 8.73l-5.145 2.958c-.415.24-.944.082-1.183-.332-.24-.415-.082-.944.332-1.183l5.145-2.958c.415-.24.944-.082 1.183.332.24.415.082.944-.332 1.183z"/>
                    </svg>
                    Join the Community
                  </a>
                </div>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <ContactForm />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      <CtaSection />
    </div>
  );
};

export default ContactPage;