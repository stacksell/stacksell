import { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, CheckCircle, DollarSign, TrendingUp, Clock, Flag } from 'lucide-react';
import { ideasData } from '../data/ideasData';
import StartNowCard from '../components/ideas/StartNowCard';

const IdeaDetailPage = () => {
  const { ideaId } = useParams<{ ideaId: string }>();
  const idea = ideasData.find(idea => idea.id === ideaId);

  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Set document title when component mounts
    if (idea) {
      document.title = `${idea.title} | StackSell`;
    } else {
      document.title = 'Idea Not Found | StackSell';
    }
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, [idea]);

  if (!idea) {
    return (
      <div className="pt-32 pb-20 min-h-screen bg-gray-50">
        <div className="container-custom">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">Idea Not Found</h1>
            <p className="text-gray-600 mb-8">
              The idea you're looking for doesn't exist or has been removed.
            </p>
            <Link to="/explore" className="btn-primary">
              Back to Ideas
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-20 bg-gray-50">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link to="/explore" className="inline-flex items-center text-gray-600 hover:text-primary-500 transition-colors">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Ideas
          </Link>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-white rounded-xl shadow-md overflow-hidden mb-8"
            >
              <div className="relative">
                <img
                  src={idea.image}
                  alt={idea.title}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {idea.category.map((tag, idx) => (
                      <span 
                        key={idx} 
                        className="inline-block px-3 py-1 text-xs font-medium text-white bg-primary-500/80 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="p-8">
                <h1 className="text-3xl font-bold mb-4">{idea.title}</h1>
                <p className="text-xl text-gray-600 mb-6">{idea.description}</p>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <DollarSign className="h-5 w-5 text-green-500 mr-2" />
                      <span className="font-medium">Earnings</span>
                    </div>
                    <p className="text-lg font-semibold">{idea.earnings}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Clock className="h-5 w-5 text-blue-500 mr-2" />
                      <span className="font-medium">Difficulty</span>
                    </div>
                    <p className="text-lg font-semibold">{idea.difficulty}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <TrendingUp className="h-5 w-5 text-purple-500 mr-2" />
                      <span className="font-medium">Investment</span>
                    </div>
                    <p className="text-lg font-semibold">{idea.investmentRequired}</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Flag className="h-5 w-5 text-yellow-500 mr-2" />
                      <span className="font-medium">Time to Start</span>
                    </div>
                    <p className="text-lg font-semibold">
                      {idea.difficulty === 'Easy' ? '1-2 Days' : 
                       idea.difficulty === 'Medium' ? '3-7 Days' : '1-2 Weeks'}
                    </p>
                  </div>
                </div>
                
                <div className="prose max-w-none">
                  <h2 className="text-2xl font-semibold mb-4">About This Business Idea</h2>
                  <p className="mb-6">{idea.fullDescription}</p>
                  
                  <h3 className="text-xl font-semibold mb-3">How to Get Started</h3>
                  <ol className="space-y-2 mb-6">
                    {idea.steps.map((step, index) => (
                      <li key={index} className="flex items-start">
                        <span className="inline-flex items-center justify-center w-6 h-6 bg-primary-100 text-primary-600 rounded-full text-sm font-medium mr-3 flex-shrink-0">
                          {index + 1}
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                  
                  <h3 className="text-xl font-semibold mb-3">Tools You'll Need</h3>
                  <ul className="space-y-2 mb-6">
                    {idea.toolsRequired.map((tool, index) => (
                      <li key={index} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>{tool}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <h3 className="text-xl font-semibold mb-3">Potential Earnings</h3>
                  <p className="mb-6">{idea.potentialEarnings}</p>
                  
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                    <h4 className="text-lg font-semibold mb-2 text-yellow-700">Pro Tips</h4>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                        <span>Start small and test the market before scaling</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                        <span>Join our community to connect with others doing this business</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                        <span>All templates and guides are included in the Starter plan</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-xl shadow-md p-8 mb-8"
            >
              <h3 className="text-xl font-semibold mb-4">Related Ideas</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {ideasData
                  .filter(i => 
                    i.id !== idea.id && 
                    i.category.some(cat => idea.category.includes(cat))
                  )
                  .slice(0, 2)
                  .map((relatedIdea, index) => (
                    <Link 
                      key={index}
                      to={`/explore/${relatedIdea.id}`}
                      className="group"
                    >
                      <div className="flex items-start space-x-4 p-4 rounded-lg border border-gray-100 hover:border-primary-200 hover:bg-primary-50 transition-colors">
                        <img 
                          src={relatedIdea.image} 
                          alt={relatedIdea.title}
                          className="w-16 h-16 rounded-md object-cover flex-shrink-0" 
                        />
                        <div>
                          <h4 className="font-medium group-hover:text-primary-600 transition-colors">
                            {relatedIdea.title}
                          </h4>
                          <p className="text-sm text-gray-600 line-clamp-2">
                            {relatedIdea.description}
                          </p>
                        </div>
                      </div>
                    </Link>
                  ))
                }
              </div>
            </motion.div>
          </div>
          
          <div className="lg:col-span-1">
            <StartNowCard />
          </div>
        </div>
      </div>
    </div>
  );
};

export default IdeaDetailPage;