import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Users, Heart, Target, ArrowRight, Award } from 'lucide-react';
import CtaSection from '../components/home/CtaSection';

const AboutPage = () => {
  useEffect(() => {
    // Set document title when component mounts
    document.title = 'About Us | StackSell';
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div>
      <div className="pt-32 pb-12 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <span className="inline-block px-4 py-2 rounded-full bg-primary-100 text-primary-600 font-medium text-sm mb-4">
              OUR STORY
            </span>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              About StackSell
            </h1>
            <p className="text-xl text-gray-600">
              We're on a mission to help teenagers, students, and anyone looking to earn online build successful businesses.
            </p>
          </motion.div>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="mb-16"
            >
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-6">
                StackSell was founded with a simple but powerful mission: to make online entrepreneurship accessible to everyone, regardless of their background, education, or financial situation.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                We believe that everyone deserves the opportunity to create financial freedom through online business, but most people don't know where to start or get lost in overwhelming, conflicting information.
              </p>
              <p className="text-lg text-gray-600">
                That's why we've created proven, step-by-step guides and templates that make it easy for anyone to start making money online, even with no prior experience or technical skills.
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="mb-16"
            >
              <div className="relative rounded-2xl overflow-hidden mb-8">
                <img
                  src="https://images.pexels.com/photos/6177607/pexels-photo-6177607.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="StackSell Team"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-6 text-white">
                    <h3 className="text-xl font-semibold mb-1">Our Growing Community</h3>
                    <p className="text-white/80">Helping thousands start their online business journey</p>
                  </div>
                </div>
              </div>
              
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-6">
                StackSell was born from our founder's own struggle to find legitimate ways to make money online as a student. After wasting time and money on scams and misleading courses, he decided to document what actually worked and share it with others.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                What started as a small blog grew into a thriving community of students, teenagers, and aspiring entrepreneurs all helping each other succeed online. Today, StackSell has helped over 10,000 people start their online business journey.
              </p>
              <p className="text-lg text-gray-600">
                We're proud to say that many of our members have gone from zero online income to running successful businesses that provide financial freedom and flexibility.
              </p>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="mb-16"
            >
              <h2 className="text-3xl font-bold mb-8">Our Values</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {[
                  {
                    icon: <Users className="h-8 w-8 text-primary-500" />,
                    title: "Accessibility",
                    description: "We make online entrepreneurship accessible to everyone, regardless of their background or resources."
                  },
                  {
                    icon: <Heart className="h-8 w-8 text-primary-500" />,
                    title: "Authenticity",
                    description: "We only recommend business models and strategies that actually work and that we've tested ourselves."
                  },
                  {
                    icon: <Target className="h-8 w-8 text-primary-500" />,
                    title: "Community",
                    description: "We believe in the power of community and helping each other succeed through shared knowledge."
                  }
                ].map((value, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white rounded-xl border border-gray-200 p-6"
                  >
                    <div className="bg-primary-50 p-3 inline-flex rounded-full mb-4">
                      {value.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                    <p className="text-gray-600">{value.description}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="mb-16"
            >
              <div className="flex flex-col md:flex-row items-center bg-gray-50 rounded-xl overflow-hidden">
                <div className="md:w-1/2 p-8">
                  <h2 className="text-2xl font-bold mb-4">Meet Our Founder</h2>
                  <p className="text-gray-600 mb-4">
                    Raj Patel started StackSell after struggling to find legitimate ways to make money online as a college student. Frustrated with the misinformation and scams in the industry, he created what he wished had existed when he was starting out.
                  </p>
                  <p className="text-gray-600 mb-6">
                    Today, he leads StackSell with a vision to democratize online entrepreneurship and help thousands of young people achieve financial freedom.
                  </p>
                  <Link
                    to="/contact"
                    className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700"
                  >
                    Get in Touch
                    <ArrowRight className="ml-1 h-5 w-5" />
                  </Link>
                </div>
                <div className="md:w-1/2">
                  <img
                    src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                    alt="Founder"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center mb-16"
            >
              <div className="mb-8">
                <Award className="h-12 w-12 text-primary-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Our Impact</h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  We measure our success by the success of our community members. Here's our impact so far:
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  { number: "10,000+", label: "Members" },
                  { number: "₹5 Crore+", label: "Earned by our community" },
                  { number: "50+", label: "Business ideas" }
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white rounded-xl border border-gray-200 p-6"
                  >
                    <p className="text-4xl font-bold text-primary-500 mb-2">{stat.number}</p>
                    <p className="text-gray-600">{stat.label}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="bg-primary-50 rounded-xl p-8 text-center"
            >
              <h2 className="text-2xl font-bold mb-4">Join Our Mission</h2>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                Whether you're a student looking to make extra income, a teenager with big dreams, or someone looking for financial freedom, StackSell is here to help you succeed.
              </p>
              <Link 
                to="/explore" 
                className="btn-primary"
              >
                Explore Ideas Now
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      <CtaSection />
    </div>
  );
};

export default AboutPage;