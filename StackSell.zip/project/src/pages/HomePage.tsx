import { useEffect } from 'react';
import HeroSection from '../components/home/HeroSection';
import FeaturesSection from '../components/home/FeaturesSection';
import TestimonialsSection from '../components/home/TestimonialsSection';
import StarterKitSection from '../components/home/StarterKitSection';
import PricingPreviewSection from '../components/home/PricingPreviewSection';
import FaqSection from '../components/home/FaqSection';
import CtaSection from '../components/home/CtaSection';

const HomePage = () => {
  useEffect(() => {
    // Set document title when component mounts
    document.title = 'StackSell – Start Your Online Hustle';
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div>
      <HeroSection />
      <FeaturesSection />
      <TestimonialsSection />
      <StarterKitSection />
      <PricingPreviewSection />
      <FaqSection />
      <CtaSection />
    </div>
  );
};

export default HomePage;