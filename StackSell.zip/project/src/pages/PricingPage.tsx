import { useEffect } from 'react';
import { motion } from 'framer-motion';
import PricingPlans from '../components/pricing/PricingPlans';
import ComparisonTable from '../components/pricing/ComparisonTable';
import TestimonialsGrid from '../components/pricing/TestimonialsGrid';
import CtaSection from '../components/home/CtaSection';

const PricingPage = () => {
  useEffect(() => {
    // Set document title when component mounts
    document.title = 'Pricing Plans | StackSell';
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div>
      <div className="pt-32 pb-10 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <span className="inline-block px-4 py-2 rounded-full bg-primary-100 text-primary-600 font-medium text-sm mb-4">
              Simple, Transparent Pricing
            </span>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Choose the Right Plan for Your Journey
            </h1>
            <p className="text-xl text-gray-600">
              All plans include access to our community and support. Upgrade or downgrade anytime.
            </p>
          </motion.div>
        </div>
      </div>

      <PricingPlans />
      <ComparisonTable />
      <TestimonialsGrid />
      <CtaSection />
    </div>
  );
};

export default PricingPage;