import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, DollarSign, Users, Gift, Award } from 'lucide-react';
import CtaSection from '../components/home/CtaSection';

const AffiliatePage = () => {
  useEffect(() => {
    // Set document title when component mounts
    document.title = 'Affiliate Program | StackSell';
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div>
      <div className="pt-32 pb-12 bg-gradient-to-b from-gray-50 to-white">
        <div className="container-custom">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <span className="inline-block px-4 py-2 rounded-full bg-primary-100 text-primary-600 font-medium text-sm mb-4">
              AFFILIATE PROGRAM
            </span>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Earn By Sharing Success
            </h1>
            <p className="text-xl text-gray-600 mb-6">
              Join our affiliate program and earn ₹200 per sale while helping others start their online business journey.
            </p>
            <Link 
              to="/signup?affiliate=true" 
              className="btn-primary"
            >
              Become an Affiliate
            </Link>
          </motion.div>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-bold mb-4">How It Works</h2>
              <p className="text-lg text-gray-600">
                Our affiliate program is designed to be simple, transparent, and profitable. Here's how you can start earning with us.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              {[
                {
                  icon: <Users className="h-8 w-8 text-primary-500" />,
                  title: "Register as Affiliate",
                  description: "Sign up for our affiliate program with a one-time fee of ₹99 to get access to all marketing materials.",
                  delay: 0
                },
                {
                  icon: <Gift className="h-8 w-8 text-primary-500" />,
                  title: "Share Your Links",
                  description: "Promote StackSell using your unique affiliate links, banners, and marketing materials.",
                  delay: 0.1
                },
                {
                  icon: <DollarSign className="h-8 w-8 text-primary-500" />,
                  title: "Earn Commissions",
                  description: "Earn ₹200 per sale with no limit on how much you can earn. We process payments weekly.",
                  delay: 0.2
                }
              ].map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: step.delay }}
                  className="bg-white rounded-xl border border-gray-200 p-6 text-center"
                >
                  <div className="bg-primary-50 p-3 inline-flex rounded-full mb-4">
                    {step.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </motion.div>
              ))}
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="bg-gray-50 rounded-xl p-8 mb-16"
            >
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold mb-2">Commission Structure</h2>
                <p className="text-gray-600">
                  We offer one of the most competitive commission rates in the industry.
                </p>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b">
                      <th className="py-4 px-6">Product</th>
                      <th className="py-4 px-6">Commission</th>
                      <th className="py-4 px-6">Payment Frequency</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="py-4 px-6">Starter Plan (₹499)</td>
                      <td className="py-4 px-6 font-semibold text-green-600">₹200 per sale</td>
                      <td className="py-4 px-6">Weekly</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-4 px-6">Premium Plan (₹1,999)</td>
                      <td className="py-4 px-6 font-semibold text-green-600">₹500 per sale</td>
                      <td className="py-4 px-6">Weekly</td>
                    </tr>
                    <tr>
                      <td className="py-4 px-6">Digital Kits</td>
                      <td className="py-4 px-6 font-semibold text-green-600">30% of sale price</td>
                      <td className="py-4 px-6">Weekly</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl border border-gray-200 p-8 mb-16"
            >
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 mb-6 md:mb-0 md:pr-8">
                  <h2 className="text-2xl font-bold mb-4">Affiliate Dashboard</h2>
                  <p className="text-gray-600 mb-4">
                    Track your performance, access marketing materials, and manage your affiliate account through our easy-to-use dashboard.
                  </p>
                  <ul className="space-y-3 mb-6">
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>Real-time commission tracking</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>Marketing materials & swipe files</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-primary-500 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span>Performance analytics</span>
                    </li>
                  </ul>
                  <Link 
                    to="/signup?affiliate=true" 
                    className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700"
                  >
                    Join Now
                    <ArrowRight className="ml-1 h-5 w-5" />
                  </Link>
                </div>
                <div className="md:w-1/2">
                  <img
                    src="https://images.pexels.com/photos/6693639/pexels-photo-6693639.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                    alt="Affiliate Dashboard"
                    className="rounded-lg shadow-md w-full"
                  />
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="text-center mb-16"
            >
              <div className="mb-8">
                <Award className="h-12 w-12 text-primary-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Success Stories</h2>
                <p className="text-gray-600">
                  Meet our top affiliates who are earning by helping others start their online journey.
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  {
                    name: "Rahul M.",
                    earnings: "₹35,000/month",
                    quote: "I started promoting StackSell to my Instagram followers, and now I earn more from affiliate commissions than my day job!",
                    image: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  },
                  {
                    name: "Priya S.",
                    earnings: "₹42,000/month",
                    quote: "As a college student, I'm now able to pay my tuition and expenses just through my StackSell affiliate earnings.",
                    image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  },
                  {
                    name: "Ajay K.",
                    earnings: "₹28,000/month",
                    quote: "I share StackSell with my YouTube audience who want to make money online, and the commissions keep flowing in.",
                    image: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  }
                ].map((story, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white rounded-xl shadow-sm p-6 text-left"
                  >
                    <div className="flex items-center mb-4">
                      <img
                        src={story.image}
                        alt={story.name}
                        className="w-12 h-12 rounded-full object-cover mr-4"
                      />
                      <div>
                        <h4 className="font-semibold">{story.name}</h4>
                        <p className="text-green-600 text-sm">{story.earnings}</p>
                      </div>
                    </div>
                    <p className="text-gray-600">"{story.quote}"</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="bg-primary-50 rounded-xl p-8 text-center"
            >
              <h2 className="text-2xl font-bold mb-4">Ready to Start Earning?</h2>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                Join our affiliate program today for just ₹99 and start earning commissions by sharing StackSell with your audience.
              </p>
              <Link 
                to="/signup?affiliate=true" 
                className="btn-primary"
              >
                Become an Affiliate Now
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      <CtaSection />
    </div>
  );
};

export default AffiliatePage;