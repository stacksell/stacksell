import { useEffect } from 'react';
import { motion } from 'framer-motion';
import AuthForm from '../components/auth/AuthForm';
import { LayoutGrid } from 'lucide-react';
import { Link } from 'react-router-dom';

const LoginPage = () => {
  useEffect(() => {
    // Set document title when component mounts
    document.title = 'Login | StackSell';
    
    // Scroll to top when component mounts
    window.scrollTo(0, 0);
    
    // Reset title when component unmounts
    return () => {
      document.title = 'StackSell – Start Your Online Hustle';
    };
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center py-16 px-4 bg-gray-50">
      <div className="w-full max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="hidden md:block"
          >
            <div className="text-center md:text-left">
              <Link to="/" className="inline-flex items-center mb-8">
                <LayoutGrid className="h-8 w-8 text-primary-500" />
                <span className="ml-2 text-2xl font-bold">StackSell</span>
              </Link>
              
              <h2 className="text-3xl font-bold mb-4">
                Welcome to Your Online Money-Making Journey
              </h2>
              <p className="text-gray-600 mb-6">
                Log in to access your dashboard, business ideas, and tools to start earning online.
              </p>
              
              <div className="relative">
                <img
                  src="https://images.pexels.com/photos/8867482/pexels-photo-8867482.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="StackSell Dashboard"
                  className="rounded-xl shadow-lg mx-auto md:mx-0"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-500/30 to-transparent rounded-xl"></div>
              </div>
            </div>
          </motion.div>
          
          <div>
            <div className="md:hidden text-center mb-8">
              <Link to="/" className="inline-flex items-center justify-center">
                <LayoutGrid className="h-8 w-8 text-primary-500" />
                <span className="ml-2 text-2xl font-bold">StackSell</span>
              </Link>
            </div>
            
            <AuthForm type="login" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;